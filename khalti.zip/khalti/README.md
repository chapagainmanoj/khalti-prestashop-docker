#khalti
# Prestashop Plugin for Khalti
